namespace Tax;
public static class TaxService{
    public static void PayIncomeTax(int amount)
    {
        Console.WriteLine("This Much Amount"+amount +"Deducted from Acount In PAYIncomeTAx");
    }
     public static void SalesTax(int amount)
    {
        Console.WriteLine("This Much Amount"+amount +"Deducted from Acount In SalesTax");
    }
 public static void PayServiceTax(int amount){

        Console.WriteLine( "Service Tax : "+ amount + "is deducted from your Bank Account");   
    }

    public static void PayGSTTax(int amount){
           Console.WriteLine( "GST Tax : "+ amount + "is deducted from your Bank Account");
    }
}