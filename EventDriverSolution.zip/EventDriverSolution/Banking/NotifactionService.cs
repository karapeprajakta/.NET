namespace Notifications;

public static class NotificationService{
    public static void SendEmail(string to,string msg)
    {
        Console.WriteLine( "Email is Sent to "+ to );
    }
     public static void SendSMS(string to,string msg)
    {
        Console.WriteLine( "Sms is Sent to "+ to );
    }
     public static void SEndWhatsApp(string to,string msg)
    {
        Console.WriteLine( "Whatsapp msg is Sent to "+ to );
    }
}