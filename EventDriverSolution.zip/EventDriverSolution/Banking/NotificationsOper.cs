namespace Notifications;
public delegate void Notification(string to,string msg);