﻿namespace Banking;
using Tax;
using Notifications;
public class Account
{
    public event Notification underBalance;
    public event TaxOperation overBalance;
    public int Balance{set;get;}
    public void Deposit(int amount)
    {
       this.Balance+=amount;
       if(this.Balance>=250000)
       {
        overBalance(5000);
       }
    } 
    public void Withdraw(int amount)
    {
     this.Balance-=amount;
      if(this.Balance<=10000)
      {
            underBalance("raj", "your account is blocked....");
        }

}}
