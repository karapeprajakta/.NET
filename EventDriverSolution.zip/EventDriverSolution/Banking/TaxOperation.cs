namespace Tax;

public delegate void TaxOperation(int amount);