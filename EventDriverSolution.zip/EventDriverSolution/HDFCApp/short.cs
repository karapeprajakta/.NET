TaxOperation abc=new TaxOperation(TaxService.PayGSTTax);
// abc(50000);
// Notification proxy1=new Notification(NotificationService.SendEmail);
// Notification proxy2=new Notification(NotificationService.SendSMS);
// Notification proxy3=new Notification(NotificationService.SEndWhatsApp);
// Notification proxy=null;
// proxy+=proxy1;
// proxy+=proxy2;
// proxy+=proxy3;

// proxy("raj","Acccount Abc");
// Console.WriteLine("dechaining..............");

//  proxy("prajwal","Balance");
//  proxy.Invoke("Praj","msh");
Console.WriteLine("------------Asynchronus calling---------------------------------------");
// IAsyncResult iResult=proxy.BeginInvoke("sarang","Thank you",null,null);
// proxy.EndInvoke(iResult);
Console.WriteLine("------------Event Handler---------------------------------------");

Account Ac1=new Account();



Ac1.overBalance+= TaxService.PayIncomeTax;
Ac1.overBalance+= TaxService.pa;



Ac1.underBalance+=NotificationService.SendEmail;
Ac1.underBalance+=NotificationService.SendSMS;
Ac1.underBalance+=NotificationService.SendSMS;

Ac1.Balance=167000;
Ac1.Deposit(166000);
