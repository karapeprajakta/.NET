﻿// See https://aka.ms/new-console-template for more information
using Banking;
using Tax;
using Notifications;
Account ac=new Account();
ac.Balance=4000000;
ac.Withdraw(10000);

int currentBal=ac.Balance;
Console.WriteLine(currentBal);
ac.Deposit(1000330);
