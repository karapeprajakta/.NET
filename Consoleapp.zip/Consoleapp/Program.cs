﻿// See https://aka.ms/new-console-template for more information
using Hardware;
using Graphic;

Device de=new Device();
de.Print();
de.Scan();

Point p=new Point(20,20);
p.Print();
Console.WriteLine(p)
;
Point p1=new Point(20,20);
Point p2=new Point(40,40);
Line l=new  Line (p1,p2,34,"c");
Console.WriteLine(l);
l.Print();

Point p5=new Point(10,20);
Circle c=new Circle(20,p5,12,"purple");
Console.WriteLine(c);


Point p6=new Point (30,40);
Point p7=new Point (30,40);
Ellipse e=new Ellipse(p6,p7,45,"red");
Console.WriteLine(e);
