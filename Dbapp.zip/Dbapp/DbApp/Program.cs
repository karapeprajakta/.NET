﻿
using System.Data;
using MySql.Data.MySqlClient;
Console.WriteLine("Hello, World!");
MySqlConnection connection =new MySqlConnection();
connection.ConnectionString="server=192.168.10.150;port=3306;user=dac38;password=welcome;database=dac38";
// string query="select * from student";
//string query="select count(*) from student";
//string query="update student set namefirst='RAj' where id=31";
// Console.WriteLine("Enter A Id:");
// int id=int.Parse(Console.ReadLine());
// string query="delete from student where id=@id";
// command.Parameters.AddWithValue("@id",id);

// Console.WriteLine("Enter A Id:");
//  int id=int.Parse(Console.ReadLine());
// Console.WriteLine("Enter A namefirst:");
// string namefirst=Console.ReadLine();
// Console.WriteLine("Enter A namelast:");
// string namelast=Console.ReadLine();
// Console.WriteLine("Enter A dob:");
// string dob=Console.ReadLine();
// Console.WriteLine("Enter A emailid:");
// string email=Console.ReadLine();
// command.Parameters.AddWithValue("@id",id);
// command.Parameters.AddWithValue("@namefirst",namefirst);
// command.Parameters.AddWithValue("@namelast",namelast);
// command.Parameters.AddWithValue("@dob",dob);
// command.Parameters.AddWithValue("@emailid",email);

// string query="insert into student values(@id,@namefirst,@namelast,@dob,@emailid)";
string query="pro100";
 MySqlCommand command=new MySqlCommand(query,connection);
// command.CommandType =new MySqlCommandType.StoredProcedure;
//  command.CommandText="pro100";
command.CommandType=CommandType.StoredProcedure;
// command.CommandText="CalculateSalary"


try{
    connection.Open();
    // MySqlDataReader reader =command.ExecuteReader();

    // while(reader.Read())
    // {
    //     int id=int.Parse(reader["id"].ToString());
    //    string namefirst=reader["namefirst"].ToString();
    //    string namelast=reader["namelast"].ToString();
    //    string dob=reader["dob"].ToString();
    //    string email=reader["emailid"].ToString();
    //    Console.WriteLine(id+" "+namefirst+" "+namelast+" "+dob+" "+email);

    // }
    // reader.Close();
    //int count=int.Parse(command.ExecuteScalar().ToString());
   // Console.WriteLine("count: "+count);

   command.ExecuteNonQuery();
}
catch(Exception e)
{
    Console.WriteLine(e.Message);
}
finally{
   connection.Close();
}
