
using HR;
public class WageEmp:Employee{
   
    public  int Hrs{
        set;get;
    }
    public double Sal{
        set; get;
    }
    public WageEmp(int id,string fullname,int hrs,double sal):base(id, fullname)
    {
        this.Hrs=hrs;
        this.Sal=sal;
    }
    public override string ToString()
    {
        return base.ToString()+" hrs: "+ Hrs +" sal: "+Sal;
    } 
    
    public override void computepay(){
     Console.WriteLine("in wageemp  sal+hrs"+(Sal*Hrs));
   }

}