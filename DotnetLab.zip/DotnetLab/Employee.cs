namespace HR;


public abstract class Employee{
// {  private int id;
//    private String fullname;
    public int Id{
        set;get;
    }
    public string Fullname{
        set;get;
    }
    public Employee():this(10,"pqr")
    {
    }
    public Employee(int i,string nm)
    {
        this.Id=i;
        this.Fullname=nm;
    }
    public abstract void computepay();
    public override String ToString()
    {
        return Id +" "+Fullname;
    } 

}