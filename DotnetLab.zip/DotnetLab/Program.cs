﻿// See https://aka.ms/new-console-template for more information
using HR;
Console.WriteLine("Hello, World!");
// Employee em=new Employee(1,"Raj Sonawane");
// Console.WriteLine(em);
WageEmp wg= new WageEmp(2,"raj",15,2000);
Console.WriteLine(wg);
SalEmp se=new SalEmp(22,"abc",10,2000,5000,9000);
Console.WriteLine(se);
se.Target=20;
Console.WriteLine(se.Target);
se.computepay();
wg.computepay();
