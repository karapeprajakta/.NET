using HR;
class SalEmp:WageEmp{
    
    public float Incentive{
        set;get;
    }
    public float Target{
        set;get;
    }
    public SalEmp():this(10,"pqr",122,4758,50000,80000){}
    public SalEmp(int id,string fullname,
    int hrs,int sal,float incentive,float target):base(id,fullname,hrs,sal)
    {
        this.Incentive=incentive;
        this.Target=target;
    }
    public override String ToString()
    {
        return base.ToString()+" "+"incentive:"+Incentive+" "+" target:"+Target;
    }
   public override void computepay(){
     Console.WriteLine("in SalEmp  tar+ins  "+(Target+Incentive));
   }
}