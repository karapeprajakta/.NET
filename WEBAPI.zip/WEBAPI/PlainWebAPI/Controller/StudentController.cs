using Microsoft.AspNetCore.Mvc;
using BOL;
using BLL;
namespace Controllers;

[ApiController]
[Route("[controller]")]
public class ProductsController : ControllerBase
{ 

    private readonly ILogger<ProductsController> _logger;

    public ProductsController(ILogger<ProductsController> logger)
    {
        _logger = logger;
    }
    [HttpGet]
    public IEnumerable <Student> Get(){

        CatlogManager cmr=new CatlogManager();
        List<Student> student=cmr.Getallstudents();
        return student.ToArray();

    }
}