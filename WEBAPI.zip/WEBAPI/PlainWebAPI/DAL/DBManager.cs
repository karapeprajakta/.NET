namespace DAL;
using MySql.Data.MySqlClient;
using BOL;
public class DBManager{
    string conString=@"server=192.168.10.150; port=3306;user=dac38;password=welcome;database=dac38";
    public static List<Student> Getallstudents(){
        List<Student> list=new List<Student>();
        MySqlConnection conn=new MySqlConnection();
        conn.ConnectionString="server=192.168.10.150; port=3306;user=dac38;password=welcome;database=dac38";
       string query="select * from student";
        MySqlCommand command=new MySqlCommand(query,conn);
        try{
            conn.Open();
            MySqlDataReader reader=command.ExecuteReader();
            while(reader.Read())
            {
                int Id=int.Parse(reader["Id"].ToString());
                string Firstname=reader["Firstname"].ToString();
                string Lastname=reader["Lastname"].ToString();
                string Email=reader["EmailId"].ToString();
                Console.WriteLine(Id+" "+Firstname+" "+Lastname+" "+Email);
            }
            reader.Close();
        }
        catch(Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }
        return list;
    }
    
}