namespace BLL;
using DAL;
using BOL;
public class CatlogManager{

    public List<Student> Getallstudents(){
        List<Student> allstudents = new List<Student>();
        allstudents=DBManager.Getallstudents();
        return allstudents;
    }

}
