namespace Dal;
using emp;
public class HRDBManager{
 public static List<Employee> GetAllEmployees()
 {
    List<Employee> get=new List<Employee>();
     get.Add(new Employee{Id=24,Firstname="Sachin",Lastname="tendulkar",Email="abc@gmail.com"});
     get.Add(new Employee{Id=25,Firstname="Sachin",Lastname="tendulkar",Email="abc@gmail.com"});
     get.Add(new Employee{Id=26,Firstname="Sachin",Lastname="tendulkar",Email="abc@gmail.com"});
     get.Add(new Employee{Id=27,Firstname="Sachin",Lastname="tendulkar",Email="abc@gmail.com"});
     get.Add(new Employee{Id=28,Firstname="Sachin",Lastname="tendulkar",Email="abc@gmail.com"});
     get.Add(new Employee{Id=29,Firstname="Sachin",Lastname="tendulkar",Email="abc@gmail.com"});
    return get;

 }
}