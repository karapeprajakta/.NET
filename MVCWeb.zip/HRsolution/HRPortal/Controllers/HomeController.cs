using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using HRPortal.Models;
using emp;
using Dal;
namespace HRPortal.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }
     public IActionResult Register()
    {
        return View();
    }
    [HttpPost]
      public IActionResult Register(string user,string Email) 
    {
        Console.WriteLine(user+" "+Email);
        return View();
    }
     [HttpPost]
      public IActionResult Login(string user,string pass) 
    {
        Console.WriteLine(user+" "+pass);
        if(user=="raj" && pass=="abcd")
        {
          
           return this.RedirectToAction("Welcome");
        }
        return View();
    }
     public IActionResult Welcome(){

       List<Employee> get=HRDBManager.GetAllEmployees();
        ViewBag.get=get;
        return View();
    }

     public IActionResult Login()
    {
        return View();
    }

    public IActionResult Index()
    {


        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
