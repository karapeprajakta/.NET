using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using HRPortal.Models;
using Dal;
using emp;
namespace HRPortal.Controllers;

public class EmployeeController : Controller
{
    private readonly ILogger<EmployeeController> _logger;

    public EmployeeController(ILogger<EmployeeController> logger)
    {
        _logger = logger;
    }
    
    public IActionResult Employeedata()
    {
        List<Employee> get=HRDBManager.GetAllEmployees();
        ViewData["get"]=get;
        return View();
    }
    public IActionResult List()
    {
        List<Employee> get=HRDBManager.GetAllEmployees();
        return View(get);
    }
    public IActionResult Details(int Id)
    {
        List<Employee> get=HRDBManager.GetAllEmployees();
        var e=get.Find((emp)=>emp.Id==Id);
        return View(e);
    }

public IActionResult Edit(int Id)
    {
        List<Employee> get=HRDBManager.GetAllEmployees();
        var e=get.Find((emp)=>emp.Id==Id);
        return View(e);
    }
    [HttpPost]
    public IActionResult Edit(Employee emp)
    {
        Console.WriteLine(emp.Id+ " " + emp.Firstname);
        if(emp!=null && ModelState.IsValid)
        {
            return RedirectToAction("List");
        }
        else 
        return View();
    }
    public IActionResult DashBoard()
    {
        return View();
    }
}