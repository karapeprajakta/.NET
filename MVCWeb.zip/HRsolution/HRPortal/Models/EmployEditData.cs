namespace emp;
public class Employee()
{
    public int Id{set;get;}
    public string Firstname{set;get;}
    public string Lastname{set;get;}
    public string Email{set;get;}
}