namespace Hardware;
public interface Printable
{ 
      void Print();
    
}