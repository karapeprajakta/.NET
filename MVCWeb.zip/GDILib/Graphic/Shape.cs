﻿namespace Graphic;

public class Shape
{
 public String Color{set;get;} 
 public int Width{set;get;} 
 public Shape():this("red",10){}
 public Shape(String co,int wi ){
    this.Color=co;
    this.Width=wi;
 }
 public override String ToString()
 {
    return " color: "+Color+" width: "+Width+" ";
 }

}
