namespace Graphic;
using Hardware;
public class Line:Shape,Printable
{
    public Point Startpoint{set;get;}
    public Point Endpoint{set;get;}
    public Line()
    {
        this.Startpoint=new Point();
        this.Endpoint=new Point();

    }
    public Line (Point p1,Point p2,int w,string c):base(c,w)
    {
        this.Startpoint=p1;
        this.Endpoint=p1;
    }
    public override String ToString()
    {
        return base.ToString() + " StartPoint :" + this.Startpoint +" Endpoint :" +this.Endpoint;
    }
    public void Draw()
    {
        Console.WriteLine("Drawing Line");
        Console.WriteLine(this);
    }
    public void Print()
    {
        Console.WriteLine("Line Printing is process.....");
    }

}
