namespace HR;


class Person{
    private int id;
    private string fname;
    private string lname;

    Person()
    {
        this.id=0;
        this.fname="null";
        this.lname="null";
    }
   public Person(int i,string f,string l )
    {
        this.id=i;
        this.fname=f;
        this.lname=l;
        
    }
          public int Id
        {
            get { return this.id; }
            set { this.id = value; }
        }
         public string Fname
       {
                get {return this.fname;}
                set {this.fname=value;}
        }
    public string Lname
    {
        get{
           return this.lname;
        }
        set{
            this.fname=value;
        }
    }
    public override string ToString() {
       return id+ " "+ fname + " "+ lname;
    }

}