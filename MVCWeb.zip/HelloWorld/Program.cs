﻿// See https://aka.ms/new-console-template for more information
using HR;
Console.WriteLine("Hello, World!");
Person prn=new Person(10,"RAj","Sonawane");
Console.WriteLine(prn);

