namespace DAL.Connection;
using BOL;

using MySql.Data.MySqlClient;

public class DBmanager
{
    
 public static string conString=@"server=192.168.10.150;port=3306;user=dac38;password=welcome;database=dac38";
   public static List<User> GetUserDetails()
   {
    List<User> GetUserDetails=new List<User>();
    MySqlConnection conn=new MySqlConnection();
    conn.ConnectionString=conString;
    string query="select * from user";
    try{
        MySqlCommand  cmd=new MySqlCommand();
        cmd.Connection=conn;
        conn.Open();
        cmd.CommandText=query;
        MySqlDataReader reader=cmd.ExecuteReader();
        while(reader.Read())
        {
            int id =int.Parse(reader["id"].ToString());
            string namefirst=reader["namefirst"].ToString();
            string namelast=reader["namelast"].ToString();
            string username=reader["Username"].ToString();
            string password=reader["password"].ToString();
            User s=new User{
                Id=id,
                Namefirst=namefirst,
                Namelast=namelast,
                Username=username,
                Password=password
            };
            GetUserDetails.Add(s);
        }
    }
    catch(Exception e)
    {
        Console.WriteLine(e.Message);
    }
    finally{

        conn.Close();
    }
    return GetUserDetails;
   } 
public static bool Validate_user(string username,string password)
{
      MySqlConnection conn=new MySqlConnection();
       conn.ConnectionString=conString;
        string query="select * from user where username=@username and password=@password ";
         MySqlCommand command=new MySqlCommand(query,conn);
        command.Parameters.AddWithValue("@username",username);
        command.Parameters.AddWithValue("@password",password);
        try{

            conn.Open();
            MySqlDataReader reader =command.ExecuteReader();
            while(reader.Read())
            {
                return true;
            }
            reader.Close();
        }
        catch(Exception e)
    {
        Console.WriteLine(e.Message);
    }
    finally{

        conn.Close();
    }
    return false;
}

   }
