﻿namespace BLL;
using BOL;
using DAL.Connection;
public class CatalogManager
{
    public static List<User> GetUserDetails()
    {
        List<User> list=new List<User>();
        list=DBmanager.GetUserDetails();
       
        return list;
    }

}
