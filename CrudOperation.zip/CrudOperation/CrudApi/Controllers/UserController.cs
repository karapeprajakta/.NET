using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using CrudApi.Models;
using DAL.Connection;
using BOL;

namespace CrudApi.Controllers;

public class UserController : Controller
{
    private readonly ILogger<UserController> _logger;

    public UserController(ILogger<UserController> logger)
    {
        _logger = logger;
    }
  public IActionResult Details()
  {
    List<User> list=DBmanager.GetUserDetails();
    ViewData["list"] =list;
    return View();

  }
   public IActionResult Login()
  {
    
    return View();

  }
  [HttpPost]
    public IActionResult Login(string username,string password)
  {
    
    bool status= DBmanager.Validate_user( username,password);
  if(status)
  {
    return this.RedirectToAction("Details");
  }
  return View();
  }
}