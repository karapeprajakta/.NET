﻿namespace BOL;

public class User
{
    public int Id{set;get;}
    public string Namefirst{set;get;}
    public string Namelast{set;get;}
    public string Username{set;get;}
    public string Password{set;get;}
   
   
}
