namespace Graphic;
using Hardware;

public class Point:Printable
{
    public int X{get; set;}
    public int Y{get; set;}
     public Point():this(0,0){}
     public Point (int a, int b)
     {
        this.X=a;
        this.Y=b;
     }
     public override String ToString()
     {
        string str=string.Format(" X={0},Y={1}", this.X,this.Y);
        return str ;
     }
     public void Print()
     {
        Console.WriteLine("Point printing is Process....");
     }
}