namespace Graphic;
using Hardware;
public class Ellipse:Shape,Printable{
    public Point StartPoint{get;set;}
    public Point Endpoint{get;set;}
    public Ellipse():base(){
        this.StartPoint=new Point(0,0);
        this.Endpoint=new Point(10,20);
    }
    public Ellipse(Point p1,Point p2, int w,String c):base(c,w)
    {
        this.StartPoint=p1;
        this.Endpoint=p2;
    }
    public void Draw()
    {
        Console.WriteLine("Drawing ellipse.....");
    }
    public void Print()
    {
        Console.WriteLine("In print of Ellipse....");

    }
    public override String ToString(){
        return base.ToString() + " StartPoint: " +this.StartPoint+ "EndPoint: "+this.Endpoint; 
    }
}