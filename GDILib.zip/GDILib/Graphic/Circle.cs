namespace Graphic;
using Hardware;

public class Circle:Shape,Printable{
  public Point Center{get;set;}
  public int Radius{get;set;}
  
  public Circle():base(){
 this.Center=new Point(0,0);
 this.Radius=5;
  }

 public Circle (int r,Point ce,int w,string c):base(c,w)
  {
    this.Center=ce;
    this.Radius=r;

  }
  public void Print()
  {
    Console.WriteLine("circle....");
  }
  public void Draw()
  {
    Console.WriteLine("Drawing circle.....");
  }

  public override String ToString()
  {
    float pi=3.14F;
    float area=pi*Radius*Radius;
    return base.ToString()+ " center: "+Center+" Radius: "+Radius+" Area : "+area;
  }

}