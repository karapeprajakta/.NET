using Hardware;

public class Device:Printable,Scanable
{
    public void Print(){
       Console.WriteLine("Printing in Process... ");
    }
    public void Scan(){
       Console.WriteLine("Scanning in Process... ");
    }
}