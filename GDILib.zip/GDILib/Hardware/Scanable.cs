namespace Hardware;
public interface Scanable
{ 
      void Scan();
    
}