namespace Paint;
using Graphic;

static class Program
{
    
    [STAThread]
    static void Main()
    {
         Line l=new Line();
        l.Startpoint=new Graphic.Point(34,45);
        l.Endpoint=new Graphic.Point(67,100);
        l.Color="Red";
        l.Width=2;
        l.Draw();
        ApplicationConfiguration.Initialize();
        Application.Run(new Form1());
        
    }    
}