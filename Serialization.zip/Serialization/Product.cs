namespace pd;
public class Product:IDisposable{
  public int Id{set;get;}
  public string Pname{set;get;}
  bool flag=false;
   public Product(){
        Id=10;
        Pname="Prajwal";
   }
 public Product(int i,string n){
        this.Id=i;
        this.Pname=n;
   }
   public void Dispose()
   {
        flag=true;
    
    
    GC.SuppressFinalize(this);
    
   }

  public void display()
  { 
     Console.WriteLine(flag);
    Console.WriteLine("Id:"+Id);
    Console.WriteLine("Pname:"+Pname);

  }
   ~Product(){
        //indeterministic finalization
         Console.WriteLine("Finalize(destructor) is invoked....");
    }


}