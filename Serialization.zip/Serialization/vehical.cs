namespace v;
public partial class Vehicle{
    public int Id{set;get;}
    public string Vname{set;get;}
    public Vehicle(int i,string n)
    {
        this.Id=i;
        this.Vname=n;
    }
    public void Display()
    {
        Console.WriteLine("id"+Id+" "+Vname);
        Console.WriteLine("In displayyy...");
    }

}