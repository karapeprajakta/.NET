namespace emp;
public class Employee{
    public virtual void calculatesalary(){
        Console.WriteLine("In Employee calculate salary...");
    }
    public virtual void dowork()
    {
         Console.WriteLine("In Employee dowork...");
    }
}
public class SalesEmp:Employee{
    public new virtual void calculatesalary()
    {
          Console.WriteLine("In salaried Employee calculatework...");

    }
    public override void dowork()
    {
        base.dowork();
    }
    
}
public class SalesManager:SalesEmp{
    public override void calculatesalary()
    {
        base.calculatesalary();
    }
}