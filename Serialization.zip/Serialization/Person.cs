namespace bsk;
public sealed class Person{
    public double PI;
    public  int Id{get;set;}
    public string FirstName{get;set;}
    public string LastName{get;set;}

    //Step 1: Singleton pattern
    public static Person _ref=null;

    //Step 2: Singleton pattern
    Person(){
        this.FirstName="Ravi";
        this.LastName="Tambade";
        this.Id=455;
        PI=3.14;
        
    }

   public  void display()
   {    
       Console.WriteLine("F : "+FirstName);
       Console.WriteLine("l : "+LastName);
       Console.WriteLine("i : "+Id);
   }

    //Step 3: Singleton pattern
    public static Person CreateInstance(){
        if (_ref ==null){
            _ref=new Person();
        }
        return _ref;
    }
}