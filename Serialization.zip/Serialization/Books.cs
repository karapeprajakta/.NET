namespace bk;
public class Books{
    public string[] titles;
    public Books()
    {
        // titles=new String [5];
        //  this.titles[0]="Rich dad Poor Dad";
    
        // this. titles[1]="fghgb";
        // this. titles[2]="bjjmnn";
        // this. titles[3]=" Dad";
        //  this. titles[4]=" Dad";
    }
    public string this[int index]
    {
       get{return titles[index];}
       set{titles[index]=value;}
    }
} 