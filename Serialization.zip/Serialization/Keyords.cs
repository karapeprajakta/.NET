namespace key;
public class Keywords{

public void swap(ref int a, ref int b)
{
    int temp=a;
    a=b;
    b=temp;
    Console.WriteLine("a: "+a +"b: "+b);
}

public void print(params string[] subject)
{
    foreach(string s in subject)
    Console.WriteLine(s);
}
public void calculate(int redius, out double area,out double cir)
{
    area =3.14*redius*redius;
    cir=2*3.14*redius;

}
}

