﻿using pd;
using bsk;
using key;
using emp;
using v;
using stack;
// Product pd=new Product(2000,"raj");
// pd.display();
// pd.Dispose();
// pd.display();



// Books myColletion=new Books();
// string title=myColletion[3];
// Console.WriteLine("Title= "+ title);
// myColletion[3]="Who moved my Cheese";
// title=myColletion[3];
// Console.WriteLine("Title= "+ title);


//Person.CreateInstance();
//Person._ref.display();

// Keywords k=new Keywords();
// int x=5;
// int y=6;
// k.swap(ref x,ref y);

// k.print("math","eng","marathi","hindi");
// double area;
// double cir;
// k.calculate(23,out area, out cir);
// Console.WriteLine( "area ={0}, circumference ={1}", area,cir);

// Employee e=new Employee();
// e.calculatesalary();
// e.dowork();

// SalesEmp se=new SalesEmp();
// Employee se2=e;
// se2.calculatesalary();
// se2.dowork();

// Employee sm=se;
// sm.calculatesalary();

// Vehicle v=new Vehicle(10,"two wheeler");
// v=new Vehicle(10,"csdfcfsd");
// v.Display();
// v.Display1();





Stack p1=new Stack(5);
Stack p2=p1;
p2.sarr[0]=67;
p2.sarr[1]=65;
p2.sarr[2]=615;
p2.sarr[3]=5;
p2.sarr[4]=6;
p2.sarr[3]=564;

 Stack p3=(Stack)p2.Clone();

p2.sarr[3]=999;

Console.WriteLine(p3.sarr[3]);
Console.WriteLine(p2.sarr[3]);
Console.WriteLine(p3.sarr[3]);
