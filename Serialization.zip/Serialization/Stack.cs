namespace stack;
public class Stack:ICloneable{
    public int size;
    public int [] sarr;
      
      public Stack(int r)
      {
        this.size=r;
        this.sarr=new int[r];
      }
     
     public object Clone(){
        Stack replica=new Stack(this.size);
        this.sarr.CopyTo(replica.sarr,0);
        return replica;

     }
}