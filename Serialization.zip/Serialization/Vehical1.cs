namespace v;
public partial class Vehicle{
    public int Tid{set;get;}
    public int Tname{set;get;}
    public Vehicle(int id,string abc,int i,int n)
    {   
        this.Tid=i;
        this.Tname=n;
    }
    public void Display1()
    {
        Console.WriteLine("id"+Tid+" "+Tname);
         Console.WriteLine("In displayyy111...");
    }
}