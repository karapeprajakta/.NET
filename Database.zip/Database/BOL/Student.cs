namespace BOL;

public class Student{
    public int Id{set;get;}
    public string Namefirst{set;get;}
    public string Namelast{set;get;}
    public string Dob{set;get;}
    public string Emailid{set;get;}


}