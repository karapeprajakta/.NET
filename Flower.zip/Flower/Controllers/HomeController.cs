using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Flower.Models;
using hr;

namespace Flower.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    { 
        Product p1=new Product();
        p1.Fname="Jasmine";
        p1.Fid=100;
        p1.Fprice=56;
        p1.Fqty=7999;
        p1.Fiurl="/images/jasmine.jpg";

        ViewData["Flower1"]=p1;
 
        Product p=new Product();
        p.Fname="Rose";
        p.Fid=101;
        p.Fprice=56;
        p.Fqty=78;
           p.Fiurl="./images/d.jpg";
 
        ViewData["Flower"]=p;

        Product p2=new Product();
        p2.Fname="Lily";
        p2.Fid=102;
        p2.Fprice=80;
        p2.Fqty=300;
        p2.Fiurl="/images/Lily.jpeg";
       
        ViewData["Flower2"]=p2;
       
        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }
     public IActionResult Aboutus()
    {
        return View();
    }
     public IActionResult Contact()
    {
        return View();
    }
    

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
