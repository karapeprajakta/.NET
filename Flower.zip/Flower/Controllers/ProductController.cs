using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Flower.Models;
using hr;

namespace Flower.Controllers;

public class ProductController : Controller
{
    private readonly ILogger<ProductController> _logger;

    public ProductController(ILogger<ProductController> logger)
    {
        _logger = logger;
    }

    public IActionResult Rose()
    { 
           Product p=new Product();
        p.Fname="Rose";
        p.Fid=101;
        p.Fprice=56;
        p.Fqty=7999;
       // p.Fiurl="/images/rose1.jpg";
       p.Fiurl="./images/d.jpg";
  
        ViewData["Flower4"]=p;
        return View();
    }
}