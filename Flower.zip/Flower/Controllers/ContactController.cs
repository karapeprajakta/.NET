using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Flower.Models;
using hr;

namespace Flower.Controllers;

public class ContactController : Controller
{
    private readonly ILogger<ContactController> _logger;

    public ContactController(ILogger<ContactController> logger)
    {
        _logger = logger;
    }

    public IActionResult Contact()
    { 
           Contact p=new Contact();
        p.Num=967899999;
        p.Email="Abc@gmail.com";
        p.Url="./images/contact.jpg";
        ViewData["contact"]=p;
        return View();
    }
}