public class Contact{
    public int Num{set;get;} 
    public String Email{set;get;}
    public String Url{set;get;}
}