namespace hr;
public class Product{
    public int Fid{set;get;}
    public String Fname{set;get;}
    public int Fqty{set;get;}
    public double Fprice{set;get;}    
    public String Fiurl{set;get;}

}